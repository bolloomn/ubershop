<?php
/**
 * Prev/next buttons
 */
?>
<button class="quick-view-prev quick-view-buttons"></button>
<button class="quick-view-next quick-view-buttons"></button>