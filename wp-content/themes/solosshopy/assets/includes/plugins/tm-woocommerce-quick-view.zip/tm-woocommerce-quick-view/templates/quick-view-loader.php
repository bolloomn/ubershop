<?php
/**
 * Popup loader template
 */
?>
<div class="tm-quick-view-loader"><div class="tm-quick-view-loader__spinner"></div></div>
